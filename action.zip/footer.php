<div class="bg-dark text-center pt-2 pb-2">All Rights Reserved</div>
</body>
</html> 
